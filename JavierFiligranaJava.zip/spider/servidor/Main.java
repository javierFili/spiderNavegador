package spider.servidor;

class Main {
  public static void main(String[] args) {
    //ServidorWeb google = new ServidorWeb("www.google.com");
    ServidorWeb javierfiligrana = new ServidorWeb("www.javierfiligrana.as");
    /* ServidorWeb csumss = new ServidorWeb("www.cs.umss.edu.bo");*/
    //google.iniciar();
    javierfiligrana.iniciar();
  }
}

