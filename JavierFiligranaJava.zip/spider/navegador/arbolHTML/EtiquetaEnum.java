package spider.navegador.arbolHTML;

public enum EtiquetaEnum {
  H1, H2, P, BODY, HTML, A,h1,h2,p,body,html
}
