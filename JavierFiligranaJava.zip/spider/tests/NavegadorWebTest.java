package spider.tests;

import org.junit.jupiter.api.Test;

class NavegadorWebTest {

  @Test
  void requestValido (){
    /*NavegadorWeb spider.navegador = new NavegadorWeb(internet);
    String pedido = "cuantos numeros primos existen";
    String spider.servidor = "apache0.0";
    spider.navegador.request(spider.servidor+";"+pedido);*/
  }

}