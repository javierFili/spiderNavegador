package spider.tests;

class BuscadorBackendTest {

}